# Doctor Management Software

## Setup Instructions

### Prerequisites
- Node.js installed
- MongoDB installed and running

### Step 1: Install Backend Dependencies
```bash
cd backend
npm install
```

### Step 2: Install Frontend Dependencies
```bash
cd frontend
npm install
```

### Step 3: Start MongoDB
```bash
# Open a new terminal and run:
mongod
```

### Step 4: Start Backend Server
```bash
# In backend folder:
cd backend
npm start
# Server runs on http://localhost:5000
```

### Step 5: Start Frontend
```bash
# In frontend folder:
cd frontend
npm run dev
# App runs on http://localhost:5173
```

## Features
- ✅ View all doctors (sorted by experience)
- ✅ Add new doctor
- ✅ Update doctor details
- ✅ Delete doctor
- ✅ Pre-seeded with 3 doctors
- ✅ Auto-refresh after operations

## API Endpoints
- GET /api/doctors - Get all doctors
- POST /api/doctors - Add new doctor
- PUT /api/doctors/:id - Update doctor
- DELETE /api/doctors/:id - Delete doctor

## Doctor Schema
- doctorId (e.g., doc001)
- doctorName
- yearsOfExperience
- qualification
- specialization
