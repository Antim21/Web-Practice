const mongoose = require('mongoose');

const doctorSchema = new mongoose.Schema({
  doctorId: { type: String, required: true, unique: true },
  doctorName: { type: String, required: true },
  yearsOfExperience: { type: Number, required: true },
  qualification: { type: String, required: true },
  specialization: { type: String, required: true }
});

module.exports = mongoose.model('Doctor', doctorSchema);
