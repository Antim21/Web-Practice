const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const Doctor = require('./models/Doctor');

const app = express();
app.use(cors());
app.use(express.json());

mongoose.connect('mongodb://localhost:27017/doctorDB')
  .then(() => console.log('MongoDB Connected'))
  .catch(err => console.log(err));

// Seed initial data
const seedData = async () => {
  const count = await Doctor.countDocuments();
  if (count === 0) {
    await Doctor.insertMany([
      { doctorId: 'doc001', doctorName: 'Dr. Sarah Johnson', yearsOfExperience: 15, qualification: 'MBBS, MD', specialization: 'Cardiology' },
      { doctorId: 'doc002', doctorName: 'Dr. Michael Chen', yearsOfExperience: 10, qualification: 'MBBS, MS', specialization: 'Orthopedics' },
      { doctorId: 'doc003', doctorName: 'Dr. Priya Sharma', yearsOfExperience: 8, qualification: 'MBBS, DNB', specialization: 'Pediatrics' }
    ]);
    console.log('Initial data seeded');
  }
};
seedData();

// GET all doctors
app.get('/api/doctors', async (req, res) => {
  try {
    const doctors = await Doctor.find().sort({ yearsOfExperience: -1 });
    res.json(doctors);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// POST new doctor
app.post('/api/doctors', async (req, res) => {
  const doctor = new Doctor(req.body);
  try {
    const newDoctor = await doctor.save();
    res.status(201).json(newDoctor);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// PUT update doctor
app.put('/api/doctors/:id', async (req, res) => {
  try {
    const updatedDoctor = await Doctor.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(updatedDoctor);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// DELETE doctor
app.delete('/api/doctors/:id', async (req, res) => {
  try {
    await Doctor.findByIdAndDelete(req.params.id);
    res.json({ message: 'Doctor deleted' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

app.listen(5001, () => console.log('Server running on port 5001'));
