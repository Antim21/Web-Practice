import { useState, useEffect } from 'react';

function App() {
  const [doctors, setDoctors] = useState([]);
  const [formData, setFormData] = useState({
    doctorId: '', doctorName: '', yearsOfExperience: '', qualification: '', specialization: ''
  });
  const [editId, setEditId] = useState(null);

  useEffect(() => {
    fetchDoctors();
  }, []);

  const fetchDoctors = async () => {
    const res = await fetch('http://localhost:5001/api/doctors');
    const data = await res.json();
    setDoctors(data);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (editId) {
      await fetch(`http://localhost:5001/api/doctors/${editId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });
      setEditId(null);
    } else {
      await fetch('http://localhost:5001/api/doctors', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });
    }
    setFormData({ doctorId: '', doctorName: '', yearsOfExperience: '', qualification: '', specialization: '' });
    fetchDoctors();
  };

  const handleEdit = (doctor) => {
    setFormData({
      doctorId: doctor.doctorId,
      doctorName: doctor.doctorName,
      yearsOfExperience: doctor.yearsOfExperience,
      qualification: doctor.qualification,
      specialization: doctor.specialization
    });
    setEditId(doctor._id);
  };

  const handleDelete = async (id) => {
    await fetch(`http://localhost:5001/api/doctors/${id}`, { method: 'DELETE' });
    fetchDoctors();
  };

  return (
    <div className="container">
      <h1 className="header">Doctor Manager Software</h1>
      
      <div className="form-card">
        <h3>{editId ? 'Update Doctor' : 'Add New Doctor'}</h3>
        <form onSubmit={handleSubmit}>
          <input
            className="form-input"
            placeholder="Doctor ID (e.g., doc004)"
            value={formData.doctorId}
            onChange={(e) => setFormData({...formData, doctorId: e.target.value})}
            required
            disabled={editId}
          />
          <input
            className="form-input"
            placeholder="Doctor Name"
            value={formData.doctorName}
            onChange={(e) => setFormData({...formData, doctorName: e.target.value})}
            required
          />
          <input
            className="form-input"
            type="number"
            placeholder="Years of Experience"
            value={formData.yearsOfExperience}
            onChange={(e) => setFormData({...formData, yearsOfExperience: e.target.value})}
            required
          />
          <input
            className="form-input"
            placeholder="Qualification"
            value={formData.qualification}
            onChange={(e) => setFormData({...formData, qualification: e.target.value})}
            required
          />
          <input
            className="form-input"
            placeholder="Specialization"
            value={formData.specialization}
            onChange={(e) => setFormData({...formData, specialization: e.target.value})}
            required
          />
          <button type="submit" className="btn-submit">{editId ? 'Update' : 'Add'}</button>
          {editId && <button type="button" className="btn-cancel" onClick={() => {
            setEditId(null);
            setFormData({ doctorId: '', doctorName: '', yearsOfExperience: '', qualification: '', specialization: '' });
          }}>Cancel</button>}
        </form>
      </div>

      <div className="doctors-grid">
        {doctors.map(doctor => (
          <div key={doctor._id} className="doctor-card">
            <div className="doctor-id">{doctor.doctorId}</div>
            <h4>{doctor.doctorName}</h4>
            <p><strong>Experience:</strong> {doctor.yearsOfExperience} years</p>
            <p><strong>Qualification:</strong> {doctor.qualification}</p>
            <p><strong>Specialization:</strong> {doctor.specialization}</p>
            <div className="card-actions">
              <button className="btn-edit" onClick={() => handleEdit(doctor)}>Edit</button>
              <button className="btn-delete" onClick={() => handleDelete(doctor._id)}>Delete</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default App;
