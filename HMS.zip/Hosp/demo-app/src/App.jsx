import { useState, useEffect } from 'react';
import axios from 'axios';
import './App.css';

const API_URL = 'http://localhost:5001/api/patients';

const emptyForm = {
    patientName: '',
    age: '',
    illness: '',
    admissionDate: '',
    ward: ''
};

function App() {
    const [patients, setPatients] = useState([]);
    const [formData, setFormData] = useState(emptyForm);
    const [editId, setEditId] = useState(null);
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        fetchPatients();
    }, []);

    const fetchPatients = async () => {
        try {
            const res = await axios.get(API_URL);
            setPatients(res.data);
            setError('');
        } catch (err) {
            // silent
        } finally {
            setLoading(false);
        }
    };

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');
        try {
            if (editId) {
                await axios.put(`${API_URL}/${editId}`, formData);
                setEditId(null);
            } else {
                await axios.post(API_URL, formData);
            }
            setFormData(emptyForm);
            fetchPatients();
        } catch (err) {
            setError(err.response?.data?.error || 'Could not save. Make sure the backend is running.');
        }
    };

    const handleEdit = (patient) => {
        setEditId(patient._id);
        setFormData({
            patientName: patient.patientName,
            age: patient.age,
            illness: patient.illness,
            admissionDate: patient.admissionDate.split('T')[0],
            ward: patient.ward || ''
        });
        window.scrollTo({ top: 0, behavior: 'smooth' });
    };

    const handleDelete = async (id) => {
        if (!window.confirm('Discharge this patient?')) return;
        try {
            await axios.delete(`${API_URL}/${id}`);
            fetchPatients();
        } catch (err) {
            setError('Could not delete. Make sure the backend is running.');
        }
    };

    const handleCancel = () => {
        setEditId(null);
        setFormData(emptyForm);
        setError('');
    };

    return (
        <div>
            <div className="hms-header">
                <h1>Hospital Management System</h1>
                <p>Manage patient admissions and records</p>
            </div>

            {error && <div className="alert alert-danger py-2 mb-3">{error}</div>}

            {/* Form */}
            <div className="card mb-4">
                <div className="card-body">
                    <h5 className="card-title mb-3">{editId ? 'Update Patient' : 'Admit New Patient'}</h5>
                    <form onSubmit={handleSubmit}>
                        <div className="row g-3">
                            <div className="col-md-6">
                                <label className="form-label">Patient Name</label>
                                <input type="text" className="form-control" name="patientName"
                                    value={formData.patientName} onChange={handleChange} required />
                            </div>
                            <div className="col-md-6">
                                <label className="form-label">Age</label>
                                <input type="number" className="form-control" name="age"
                                    value={formData.age} onChange={handleChange} required />
                            </div>
                            <div className="col-md-6">
                                <label className="form-label">Illness / Diagnosis</label>
                                <input type="text" className="form-control" name="illness"
                                    value={formData.illness} onChange={handleChange} required />
                            </div>
                            <div className="col-md-6">
                                <label className="form-label">Admission Date</label>
                                <input type="date" className="form-control" name="admissionDate"
                                    value={formData.admissionDate} onChange={handleChange} required />
                            </div>
                            <div className="col-12">
                                <label className="form-label">Ward / Room Number</label>
                                <input type="text" className="form-control" name="ward"
                                    value={formData.ward} onChange={handleChange} placeholder="e.g. Ward 3, Room 101" />
                            </div>
                            <div className="col-12 d-flex gap-2">
                                <button type="submit" className="btn btn-primary">
                                    {editId ? 'Update Patient' : 'Admit Patient'}
                                </button>
                                {editId && (
                                    <button type="button" className="btn btn-secondary" onClick={handleCancel}>
                                        Cancel
                                    </button>
                                )}
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            {/* Table */}
            <div className="card">
                <div className="card-body">
                    <h5 className="card-title mb-3">
                        Admitted Patients <span className="badge bg-secondary">{patients.length}</span>
                    </h5>
                    {loading ? (
                        <p className="text-muted">Loading...</p>
                    ) : (
                        <div className="table-responsive">
                            <table className="table table-bordered table-hover align-middle mb-0">
                                <thead className="table-light">
                                    <tr>
                                        <th>Ward / Room</th>
                                        <th>Patient Name</th>
                                        <th>Age</th>
                                        <th>Illness</th>
                                        <th>Admission Date</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {patients.length > 0 ? patients.map((p) => (
                                        <tr key={p._id}>
                                            <td>{p.ward || <span className="text-muted">-</span>}</td>
                                            <td className="fw-semibold">{p.patientName}</td>
                                            <td>{p.age}</td>
                                            <td>{p.illness}</td>
                                            <td>{new Date(p.admissionDate).toLocaleDateString()}</td>
                                            <td>
                                                <div className="d-flex gap-2">
                                                    <button className="btn btn-sm btn-outline-primary"
                                                        onClick={() => handleEdit(p)}>Edit</button>
                                                    <button className="btn btn-sm btn-outline-danger"
                                                        onClick={() => handleDelete(p._id)}>Discharge</button>
                                                </div>
                                            </td>
                                        </tr>
                                    )) : (
                                        <tr>
                                            <td colSpan="6" className="text-center text-muted py-4">
                                                No patients admitted currently.
                                            </td>
                                        </tr>
                                    )}
                                </tbody>
                            </table>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}

export default App;
