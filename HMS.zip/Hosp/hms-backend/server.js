const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const app = express();
const PORT = 5001;

app.use(cors());
app.use(express.json());

mongoose.connect('mongodb://127.0.0.1:27017/hospitalDB')
    .then(() => console.log('Connected to MongoDB: hospitalDB'))
    .catch(err => console.error('MongoDB connection error:', err));

const patientSchema = new mongoose.Schema({
    patientName:   { type: String, required: true },
    age:           { type: Number, required: true },
    illness:       { type: String, required: true },
    admissionDate: { type: Date,   required: true },
    ward:          { type: String, default: '' }
});

const Patient = mongoose.model('Patient', patientSchema);

// GET all patients sorted by oldest admission first
app.get('/api/patients', async (req, res) => {
    try {
        const patients = await Patient.find().sort({ admissionDate: 1 });
        res.json(patients);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// POST add new patient
app.post('/api/patients', async (req, res) => {
    try {
        const patient = new Patient(req.body);
        await patient.save();
        res.status(201).json(patient);
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
});

// PUT update patient
app.put('/api/patients/:id', async (req, res) => {
    try {
        const updated = await Patient.findByIdAndUpdate(req.params.id, req.body, { new: true });
        res.json(updated);
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
});

// DELETE patient
app.delete('/api/patients/:id', async (req, res) => {
    try {
        await Patient.findByIdAndDelete(req.params.id);
        res.json({ message: 'Patient discharged successfully' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
