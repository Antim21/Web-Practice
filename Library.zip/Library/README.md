# Library Book Manager

## Requirements
- Node.js
- MongoDB (running locally)

## Setup & Run

### 1. Start MongoDB
```bash
brew services start mongodb-community
```

### 2. Backend
```bash
cd library-backend
npm install
node server.js
```

### 3. Frontend (new terminal)
```bash
cd library-app
npm install
npm run dev
```

Open http://localhost:5173
