import { useState, useEffect } from 'react';
import axios from 'axios';


const API_URL = 'http://localhost:5002/api/books';

const emptyForm = {
    title: '',
    author: '',
    isbn: '',
    genre: '',
    publishedYear: '',
    status: 'Available',
    issuedTo: ''
};

function App() {
    const [books, setBooks] = useState([]);
    const [formData, setFormData] = useState(emptyForm);
    const [editId, setEditId] = useState(null);
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        fetchBooks();
    }, []);

    const fetchBooks = async () => {
        try {
            const res = await axios.get(API_URL);
            setBooks(res.data);
            setError('');
        } catch (err) {
            // silent
        } finally {
            setLoading(false);
        }
    };

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({
            ...prev,
            [name]: value,
            ...(name === 'status' && value === 'Available' ? { issuedTo: '' } : {})
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');
        try {
            if (editId) {
                await axios.put(`${API_URL}/${editId}`, formData);
                setEditId(null);
            } else {
                await axios.post(API_URL, formData);
            }
            setFormData(emptyForm);
            fetchBooks();
        } catch (err) {
            setError(err.response?.data?.error || 'Could not save. Make sure the backend is running.');
        }
    };

    const handleEdit = (book) => {
        setEditId(book._id);
        setFormData({
            title: book.title,
            author: book.author,
            isbn: book.isbn,
            genre: book.genre || '',
            publishedYear: book.publishedYear || '',
            status: book.status,
            issuedTo: book.issuedTo || ''
        });
        window.scrollTo({ top: 0, behavior: 'smooth' });
    };

    const handleDelete = async (id) => {
        if (!window.confirm('Delete this book?')) return;
        try {
            await axios.delete(`${API_URL}/${id}`);
            fetchBooks();
        } catch (err) {
            setError('Could not delete. Make sure the backend is running.');
        }
    };

    const handleCancel = () => {
        setEditId(null);
        setFormData(emptyForm);
        setError('');
    };

    const available = books.filter(b => b.status === 'Available').length;
    const issued = books.filter(b => b.status === 'Issued').length;

    return (
        <div>
            <div className="lib-header">
                <h1>Library Book Manager</h1>
                <p>Manage books, authors and issue status</p>
            </div>

            {error && <div className="alert alert-danger py-2 mb-3">{error}</div>}

            {/* Summary */}
            <div className="row g-3 mb-4">
                <div className="col-md-4">
                    <div className="card text-center">
                        <div className="card-body py-2">
                            <div className="fs-4 fw-bold">{books.length}</div>
                            <div className="text-muted small">Total Books</div>
                        </div>
                    </div>
                </div>
                <div className="col-md-4">
                    <div className="card text-center">
                        <div className="card-body py-2">
                            <div className="fs-4 fw-bold text-success">{available}</div>
                            <div className="text-muted small">Available</div>
                        </div>
                    </div>
                </div>
                <div className="col-md-4">
                    <div className="card text-center">
                        <div className="card-body py-2">
                            <div className="fs-4 fw-bold text-danger">{issued}</div>
                            <div className="text-muted small">Issued</div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Form */}
            <div className="card mb-4">
                <div className="card-body">
                    <h5 className="card-title mb-3">{editId ? 'Update Book' : 'Add New Book'}</h5>
                    <form onSubmit={handleSubmit}>
                        <div className="row g-3">
                            <div className="col-md-6">
                                <label className="form-label">Book Title</label>
                                <input type="text" className="form-control" name="title"
                                    value={formData.title} onChange={handleChange} required />
                            </div>
                            <div className="col-md-6">
                                <label className="form-label">Author</label>
                                <input type="text" className="form-control" name="author"
                                    value={formData.author} onChange={handleChange} required />
                            </div>
                            <div className="col-md-4">
                                <label className="form-label">ISBN</label>
                                <input type="text" className="form-control" name="isbn"
                                    value={formData.isbn} onChange={handleChange} required />
                            </div>
                            <div className="col-md-4">
                                <label className="form-label">Genre</label>
                                <input type="text" className="form-control" name="genre"
                                    value={formData.genre} onChange={handleChange} placeholder="e.g. Fiction" />
                            </div>
                            <div className="col-md-4">
                                <label className="form-label">Published Year</label>
                                <input type="number" className="form-control" name="publishedYear"
                                    value={formData.publishedYear} onChange={handleChange} placeholder="e.g. 2020" />
                            </div>
                            <div className="col-md-4">
                                <label className="form-label">Status</label>
                                <select className="form-select" name="status" value={formData.status} onChange={handleChange}>
                                    <option value="Available">Available</option>
                                    <option value="Issued">Issued</option>
                                </select>
                            </div>
                            {formData.status === 'Issued' && (
                                <div className="col-md-8">
                                    <label className="form-label">Issued To</label>
                                    <input type="text" className="form-control" name="issuedTo"
                                        value={formData.issuedTo} onChange={handleChange} placeholder="Student / Member name" required />
                                </div>
                            )}
                            <div className="col-12 d-flex gap-2">
                                <button type="submit" className="btn btn-success">
                                    {editId ? 'Update Book' : 'Add Book'}
                                </button>
                                {editId && (
                                    <button type="button" className="btn btn-secondary" onClick={handleCancel}>
                                        Cancel
                                    </button>
                                )}
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            {/* Table */}
            <div className="card">
                <div className="card-body">
                    <h5 className="card-title mb-3">
                        All Books <span className="badge bg-secondary">{books.length}</span>
                    </h5>
                    {loading ? (
                        <p className="text-muted">Loading...</p>
                    ) : (
                        <div className="table-responsive">
                            <table className="table table-bordered table-hover align-middle mb-0">
                                <thead className="table-light">
                                    <tr>
                                        <th>Title</th>
                                        <th>Author</th>
                                        <th>ISBN</th>
                                        <th>Genre</th>
                                        <th>Year</th>
                                        <th>Status</th>
                                        <th>Issued To</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {books.length > 0 ? books.map((b) => (
                                        <tr key={b._id}>
                                            <td className="fw-semibold">{b.title}</td>
                                            <td>{b.author}</td>
                                            <td>{b.isbn}</td>
                                            <td>{b.genre || <span className="text-muted">-</span>}</td>
                                            <td>{b.publishedYear || <span className="text-muted">-</span>}</td>
                                            <td>
                                                <span className={`badge ${b.status === 'Available' ? 'bg-success' : 'bg-danger'}`}>
                                                    {b.status}
                                                </span>
                                            </td>
                                            <td>{b.issuedTo || <span className="text-muted">-</span>}</td>
                                            <td>
                                                <div className="d-flex gap-2">
                                                    <button className="btn btn-sm btn-outline-primary"
                                                        onClick={() => handleEdit(b)}>Edit</button>
                                                    <button className="btn btn-sm btn-outline-danger"
                                                        onClick={() => handleDelete(b._id)}>Delete</button>
                                                </div>
                                            </td>
                                        </tr>
                                    )) : (
                                        <tr>
                                            <td colSpan="8" className="text-center text-muted py-4">
                                                No books added yet.
                                            </td>
                                        </tr>
                                    )}
                                </tbody>
                            </table>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}

export default App;
