const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const app = express();
const PORT = 5002;

app.use(cors());
app.use(express.json());

mongoose.connect('mongodb://127.0.0.1:27017/libraryDB')
    .then(() => console.log('Connected to MongoDB: libraryDB'))
    .catch(err => console.error('MongoDB connection error:', err));

const bookSchema = new mongoose.Schema({
    title:       { type: String, required: true },
    author:      { type: String, required: true },
    isbn:        { type: String, required: true, unique: true },
    genre:       { type: String, default: '' },
    publishedYear: { type: Number, default: null },
    status:      { type: String, enum: ['Available', 'Issued'], default: 'Available' },
    issuedTo:    { type: String, default: '' }
}, { timestamps: true });

const Book = mongoose.model('Book', bookSchema);

app.get('/api/books', async (req, res) => {
    try {
        const books = await Book.find().sort({ createdAt: 1 });
        res.json(books);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.post('/api/books', async (req, res) => {
    try {
        const book = new Book(req.body);
        await book.save();
        res.status(201).json(book);
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
});

app.put('/api/books/:id', async (req, res) => {
    try {
        const updated = await Book.findByIdAndUpdate(req.params.id, req.body, { new: true });
        res.json(updated);
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
});

app.delete('/api/books/:id', async (req, res) => {
    try {
        await Book.findByIdAndDelete(req.params.id);
        res.json({ message: 'Book deleted successfully' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
