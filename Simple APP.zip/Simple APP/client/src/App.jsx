import { useState, useEffect } from "react";
import { getEmployees, addEmployee, updateEmployee, deleteEmployee } from "./api";

const empty = { name: "", email: "", department: "", role: "", salary: "", joinDate: "" };

export default function App() {
  const [employees, setEmployees] = useState([]);
  const [form, setForm] = useState(empty);
  const [editing, setEditing] = useState(null);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);

  const fetchEmployees = async () => {
    setLoading(true);
    const { data } = await getEmployees();
    setEmployees(data);
    setLoading(false);
  };

  useEffect(() => { fetchEmployees(); }, []);

  const handle = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (editing) {
      await updateEmployee(editing._id, form);
    } else {
      await addEmployee(form);
    }
    setForm(empty);
    setEditing(null);
    fetchEmployees();
  };

  const handleEdit = (emp) => {
    setEditing(emp);
    setForm({ ...emp, joinDate: emp.joinDate?.slice(0, 10) });
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleDelete = async (id) => {
    if (window.confirm("Delete this employee?")) {
      await deleteEmployee(id);
      fetchEmployees();
    }
  };

  const handleCancel = () => {
    setEditing(null);
    setForm(empty);
  };

  const filtered = employees.filter((e) =>
    e.name.toLowerCase().includes(search.toLowerCase()) ||
    e.department.toLowerCase().includes(search.toLowerCase()) ||
    e.role.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <>
      <nav>Employee Management System</nav>
      <div className="container">

        <div className="form-section">
          <h3>{editing ? "Edit Employee" : "Add Employee"}</h3>
          <form onSubmit={handleSubmit}>
            <div className="form-grid">
              {[
                { label: "Full Name", name: "name", type: "text" },
                { label: "Email", name: "email", type: "email" },
                { label: "Department", name: "department", type: "text" },
                { label: "Role", name: "role", type: "text" },
                { label: "Salary", name: "salary", type: "number" },
                { label: "Join Date", name: "joinDate", type: "date" },
              ].map(({ label, name, type }) => (
                <div className="form-group" key={name}>
                  <label>{label}</label>
                  <input type={type} name={name} value={form[name]} onChange={handle} required />
                </div>
              ))}
            </div>
            <div className="form-actions">
              {editing && (
                <button type="button" className="btn-cancel" onClick={handleCancel}>Cancel</button>
              )}
              <button type="submit" className="btn-primary">
                {editing ? "Update Employee" : "Add Employee"}
              </button>
            </div>
          </form>
        </div>

        <div className="table-section">
          <div className="top-bar">
            <input
              type="text"
              placeholder="Search by name, department, role..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
            <span style={{ fontSize: "0.875rem", color: "#555" }}>
              Total Employees: {employees.length}
            </span>
          </div>

          {loading ? (
            <div className="no-data">Loading...</div>
          ) : filtered.length === 0 ? (
            <div className="no-data">No employees found.</div>
          ) : (
            <table>
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Department</th>
                  <th>Role</th>
                  <th>Salary</th>
                  <th>Join Date</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((emp) => (
                  <tr key={emp._id}>
                    <td>{emp.name}</td>
                    <td>{emp.email}</td>
                    <td>{emp.department}</td>
                    <td>{emp.role}</td>
                    <td>{Number(emp.salary).toLocaleString()}</td>
                    <td>{new Date(emp.joinDate).toLocaleDateString("en-IN")}</td>
                    <td>
                      <button className="btn-edit" onClick={() => handleEdit(emp)}>Edit</button>
                      <button className="btn-delete" onClick={() => handleDelete(emp._id)}>Delete</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

      </div>
    </>
  );
}
