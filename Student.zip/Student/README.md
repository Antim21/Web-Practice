# Student Management System

A full-stack web application to manage student records using React, Express, and MongoDB.

---

## Tech Stack

- Frontend: React (Vite), Axios
- Backend: Node.js, Express
- Database: MongoDB

---

## Prerequisites

### 1. Install Node.js
- Download from: https://nodejs.org (LTS version)
- Verify: `node -v` and `npm -v`

### 2. Install MongoDB
- Download from: https://www.mongodb.com/try/download/community
- Verify: `mongod --version`

### 3. Start MongoDB

**macOS:**
```
brew services start mongodb-community
```
**Windows:**
```
net start MongoDB
```
**Linux:**
```
sudo systemctl start mongod
```

---

## Project Structure

```
Student/
├── server/    → Express backend (API + MongoDB)
└── client/    → React frontend (UI)
```

---

## Setup & Run

### Step 1 — Setup the Backend

```
cd Student/server
npm install
node index.js
```

You should see:
```
MongoDB connected
Server running on http://localhost:5002
```

### Step 2 — Setup the Frontend

Open a second terminal:

```
cd Student/client
npm install
npm run dev
```

You should see:
```
VITE ready on http://localhost:5173
```

### Step 3 — Open the App

```
http://localhost:5173
```

---

## Features

- Add new students
- Edit existing student details
- Delete students
- Search by name, course, or grade
- Students sorted by enroll date (oldest first)

---

## Student Fields

| Field       | Type   |
|-------------|--------|
| Full Name   | Text   |
| Email       | Email  |
| Course      | Text   |
| Grade       | A-F    |
| Age         | Number |
| Enroll Date | Date   |

---

## Ports Used

| Service  | Port  |
|----------|-------|
| Backend  | 5002  |
| Frontend | 5173  |
| MongoDB  | 27017 |
