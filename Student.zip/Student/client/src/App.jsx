import { useState, useEffect } from "react";
import { getStudents, addStudent, updateStudent, deleteStudent } from "./api";

const empty = { name: "", email: "", course: "", grade: "", age: "", enrollDate: "" };

const grades = ["A", "B", "C", "D", "F"];

export default function App() {
  const [students, setStudents] = useState([]);
  const [form, setForm] = useState(empty);
  const [editing, setEditing] = useState(null);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);

  const fetchStudents = async () => {
    setLoading(true);
    const { data } = await getStudents();
    setStudents(data);
    setLoading(false);
  };

  useEffect(() => { fetchStudents(); }, []);

  const handle = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (editing) {
      await updateStudent(editing._id, form);
    } else {
      await addStudent(form);
    }
    setForm(empty);
    setEditing(null);
    fetchStudents();
  };

  const handleEdit = (s) => {
    setEditing(s);
    setForm({ ...s, enrollDate: s.enrollDate?.slice(0, 10) });
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleDelete = async (id) => {
    if (window.confirm("Delete this student?")) {
      await deleteStudent(id);
      fetchStudents();
    }
  };

  const handleCancel = () => {
    setEditing(null);
    setForm(empty);
  };

  const filtered = students.filter((s) =>
    s.name.toLowerCase().includes(search.toLowerCase()) ||
    s.course.toLowerCase().includes(search.toLowerCase()) ||
    s.grade.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <>
      <header>Student Management System</header>
      <div className="page">

        <div className="form-card">
          <h2>{editing ? "Edit Student" : "Add Student"}</h2>
          <form onSubmit={handleSubmit}>
            <div className="form-grid">
              <div className="form-group">
                <label>Full Name</label>
                <input type="text" name="name" value={form.name} onChange={handle} required />
              </div>
              <div className="form-group">
                <label>Email</label>
                <input type="email" name="email" value={form.email} onChange={handle} required />
              </div>
              <div className="form-group">
                <label>Course</label>
                <input type="text" name="course" value={form.course} onChange={handle} required />
              </div>
              <div className="form-group">
                <label>Grade</label>
                <select name="grade" value={form.grade} onChange={handle} required>
                  <option value="">Select</option>
                  {grades.map((g) => <option key={g} value={g}>{g}</option>)}
                </select>
              </div>
              <div className="form-group">
                <label>Age</label>
                <input type="number" name="age" value={form.age} onChange={handle} required min="5" max="100" />
              </div>
              <div className="form-group">
                <label>Enroll Date</label>
                <input type="date" name="enrollDate" value={form.enrollDate} onChange={handle} required />
              </div>
            </div>
            <div className="form-actions">
              {editing && (
                <button type="button" className="btn-cancel" onClick={handleCancel}>Cancel</button>
              )}
              <button type="submit" className="btn-primary">
                {editing ? "Update Student" : "Add Student"}
              </button>
            </div>
          </form>
        </div>

        <div className="table-card">
          <div className="table-header">
            <input
              type="text"
              placeholder="Search by name, course, grade..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
            <span>Total: {students.length} students</span>
          </div>

          {loading ? (
            <div className="no-data">Loading...</div>
          ) : filtered.length === 0 ? (
            <div className="no-data">No students found.</div>
          ) : (
            <table>
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Course</th>
                  <th>Grade</th>
                  <th>Age</th>
                  <th>Enroll Date</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((s) => (
                  <tr key={s._id}>
                    <td>{s.name}</td>
                    <td>{s.email}</td>
                    <td>{s.course}</td>
                    <td><span className="grade-badge">{s.grade}</span></td>
                    <td>{s.age}</td>
                    <td>{new Date(s.enrollDate).toLocaleDateString("en-IN")}</td>
                    <td>
                      <button className="btn-edit" onClick={() => handleEdit(s)}>Edit</button>
                      <button className="btn-delete" onClick={() => handleDelete(s._id)}>Delete</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

      </div>
    </>
  );
}
