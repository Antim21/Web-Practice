# Todo App - MySQL Version Setup

## Prerequisites
- Node.js installed
- MySQL installed and running

## MySQL Database Setup

1. **Start MySQL:**
   ```bash
   mysql -u root -p
   ```

2. **Create Database:**
   ```sql
   CREATE DATABASE todoapp;
   EXIT;
   ```

## Backend Setup

1. **Install mysql2 dependency:**
   ```bash
   cd backend
   npm install mysql2
   ```

2. **Update MySQL password in server-mysql.js:**
   - Open `backend/server-mysql.js`
   - Change `password: 'your_password'` to your MySQL root password

3. **Start MySQL server:**
   ```bash
   node server-mysql.js
   ```
   Server will run on http://localhost:5001

## Frontend Setup

1. **Replace App.jsx with MySQL version:**
   ```bash
   cd frontend
   cp src/App-mysql.jsx src/App.jsx
   ```

2. **Start frontend:**
   ```bash
   npm run dev
   ```
   App will run on http://localhost:5173

## Key Differences from MongoDB Version

### Database:
- MongoDB uses `_id` (string) → MySQL uses `id` (integer)
- MongoDB is schema-less → MySQL requires table structure
- MongoDB uses collections → MySQL uses tables

### Backend:
- `server.js` - MongoDB version (uses mongoose)
- `server-mysql.js` - MySQL version (uses mysql2)

### Frontend:
- `App.jsx` - MongoDB version (uses `todo._id`)
- `App-mysql.jsx` - MySQL version (uses `todo.id`)

## Switching Between Versions

### To use MongoDB:
```bash
# Backend
cd backend
node server.js

# Frontend - use default App.jsx
```

### To use MySQL:
```bash
# Backend
cd backend
node server-mysql.js

# Frontend
cp src/App-mysql.jsx src/App.jsx
npm run dev
```

## Table Structure (Auto-created)
```sql
CREATE TABLE todos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  completed BOOLEAN DEFAULT false,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```
