const express = require('express');
const mysql = require('mysql2/promise');
const cors = require('cors');

const app = express();

app.use(cors());
app.use(express.json());

// MySQL connection pool
const pool = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: 'your_password', // Change this to your MySQL password
  database: 'todoapp'
});

// Test connection and create table if not exists
(async () => {
  try {
    const connection = await pool.getConnection();
    console.log('MySQL connected');
    
    // Create table if not exists
    await connection.query(`
      CREATE TABLE IF NOT EXISTS todos (
        id INT AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        completed BOOLEAN DEFAULT false,
        createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);
    console.log('Table ready');
    connection.release();
  } catch (err) {
    console.log('MySQL connection error:', err);
  }
})();

// Get all todos
app.get('/api/todos', async (req, res) => {
  try {
    const [todos] = await pool.query('SELECT * FROM todos ORDER BY createdAt ASC');
    res.json(todos);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Create todo
app.post('/api/todos', async (req, res) => {
  try {
    const [result] = await pool.query('INSERT INTO todos (title) VALUES (?)', [req.body.title]);
    const [newTodo] = await pool.query('SELECT * FROM todos WHERE id = ?', [result.insertId]);
    res.status(201).json(newTodo[0]);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// Update todo
app.put('/api/todos/:id', async (req, res) => {
  try {
    const { title, completed } = req.body;
    const [todo] = await pool.query('SELECT * FROM todos WHERE id = ?', [req.params.id]);
    
    if (todo.length === 0) {
      return res.status(404).json({ message: 'Todo not found' });
    }

    const updateTitle = title !== undefined ? title : todo[0].title;
    const updateCompleted = completed !== undefined ? completed : todo[0].completed;

    await pool.query('UPDATE todos SET title = ?, completed = ? WHERE id = ?', 
      [updateTitle, updateCompleted, req.params.id]);
    
    const [updatedTodo] = await pool.query('SELECT * FROM todos WHERE id = ?', [req.params.id]);
    res.json(updatedTodo[0]);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// Delete todo
app.delete('/api/todos/:id', async (req, res) => {
  try {
    await pool.query('DELETE FROM todos WHERE id = ?', [req.params.id]);
    res.json({ message: 'Todo deleted' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

const PORT = 5001;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
